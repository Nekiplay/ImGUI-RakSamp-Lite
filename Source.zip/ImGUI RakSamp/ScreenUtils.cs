﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImGUI_RakSamp
{
    public class ScreenUtils
    {
        public Size GetSize()
        {
            int width = 0;
            int height = 0;
            var managementScope = new System.Management.ManagementScope();
            managementScope.Connect();
            var q = new System.Management.ObjectQuery("SELECT CurrentHorizontalResolution, CurrentVerticalResolution FROM Win32_VideoController");
            var searcher = new System.Management.ManagementObjectSearcher(managementScope, q);
            var records = searcher.Get();
            foreach (var record in records)
            {
                if (!int.TryParse(record.GetPropertyValue("CurrentHorizontalResolution").ToString(), out width))
                {
                    throw new Exception("Throw some exception");
                }
                if (!int.TryParse(record.GetPropertyValue("CurrentVerticalResolution").ToString(), out height))
                {
                    throw new Exception("Throw some exception");
                }
            }
            return new Size(width, height);
        }
    }
}
