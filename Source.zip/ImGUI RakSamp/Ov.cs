﻿using ClickableTransparentOverlay;
using ImGuiNET;
using Memory;
using MyApp;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImGUI_RakSamp
{
    public class Ov : Overlay
    {
        protected override void Render()
        {
            Size = Program.size;

            ImGui.Begin("RakSamp | " + Program.mem.ReadString("0057A072") + " [" + Program.mem.Read2Byte("004D36AC") + "]", ImGuiWindowFlags.NoScrollbar);
            var money = Program.mem.ReadLong("004D36C8");

            ImGui.Text("Money: " + FormatNumber(money));
            ImGui.SameLine(140);
            ImGui.Text("Health: " + Program.mem.Read2Byte("004AF980"));
            ImGui.End();
        }

        internal static string FormatNumber(long num)
        {
            num = MaxThreeSignificantDigits(num);

            if (num >= 100000000)
                return (num / 1000000D).ToString("0.#M");
            if (num >= 1000000)
                return (num / 1000000D).ToString("0.##M");
            if (num >= 100000)
                return (num / 1000D).ToString("0k");
            if (num >= 100000)
                return (num / 1000D).ToString("0.#k");
            if (num >= 1000)
                return (num / 1000D).ToString("0.##k");
            return num.ToString("#,0");
        }


        internal static long MaxThreeSignificantDigits(long x)
        {
            int i = (int)Math.Log10(x);
            i = Math.Max(0, i - 2);
            i = (int)Math.Pow(10, i);
            return x / i * i;
        }
    }
}
