﻿using ImGUI_RakSamp;
using Memory;
using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        public  static Mem mem = new Mem();
        public static System.Drawing.Size size = new System.Drawing.Size();
        static void Main(string[] args)
        {
            Console.Write("RakSAMP PID: ");
            int pid = -1;
            int.TryParse(Console.ReadLine(), out pid);

            System.Diagnostics.Process process = System.Diagnostics.Process.GetProcessById(pid);
            if (process != null)
            {
                Process.NET.ProcessSharp processSharp = new Process.NET.ProcessSharp(process, Process.NET.Memory.MemoryType.Local);
                IntPtr baseAdress = processSharp.ModuleFactory["RakSAMP Lite.exe"].BaseAddress;

                mem.OpenProcess(pid);

                long money = mem.ReadLong("004D36C8");
                int health = mem.Read2Byte("004AF980");
                int id = mem.Read2Byte("004D36AC");
                int skin = mem.Read2Byte("004D3758");
                string nickname = mem.ReadString("0057A072");


                string name3 = GetPlayerName(999, mem);
                Console.WriteLine(name3);

                GetInput(mem);

                size = new ScreenUtils().GetSize();

                Ov ov = new Ov();
                ov.Run();

                Console.WriteLine(money);
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Error Process not found");
                Console.ReadKey();
            }
        }

        static string GetPlayerName(int id, Mem mem)
        {
            if (id > 1000 || id < 0)
            {
                return "";
            }
            int addres = 0x004E88E3;
            if (id > 0)
            {
                addres = addres + (0x15E * id);
            }
            return mem.ReadString(addres.ToString("X"));
        }

        static string GetInput(Mem mem)
        {
            int lenght = mem.ReadInt("RakSAMP Lite.exe+0x32C4,0x38,0x54,0x4,0x18C,0x3C,0x48,0xE94");
            Console.WriteLine(lenght);
            return "";
        }
    }
}